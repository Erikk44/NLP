# Common utils

This folder stores collection of functions that are common for different assignments

- `download_utils.py`: Functions for downloading data for the assignments.
